XLS.parse_xlscfb = parse_xlscfb;
XLS.read = xlsread;
XLS.readFile = readFile;
XLS.readSync = xlsread;
XLS.readFileSync = readFile;
XLS.utils = utils;
XLS.CFB = CFB;
XLS.SSF = SSF;
