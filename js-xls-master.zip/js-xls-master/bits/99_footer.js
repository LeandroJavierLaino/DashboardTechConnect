})(typeof exports !== 'undefined' ? exports : XLS);
